#ifndef TEST_H
#define TEST_H
char* PrintHello();
#endif
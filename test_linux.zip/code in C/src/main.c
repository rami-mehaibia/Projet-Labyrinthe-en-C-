#include "../include/SDL.h"
#include <stdio.h>
#include <stdlib.h>
#include "../unity/src/unity.h"
#include "test.h"
#include "structenum.h"
#include "begin.h"
#include"game.h"
//#include "../sdl/include/SDL.h"
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"
#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600
/*
SDL_RENDERER_SOFTWARE
SDL_RENDERER_ACCELERATED
SDL_RENDERER_PRESENTVSYNC
SDL_RENDERER_TARGETTEXTURE
*/

//Test
void SDL_ExitWithError(const char* message){
  SDL_Log("ERREUR : %s > %s\n",message,SDL_GetError());
  SDL_Quit();
  exit(EXIT_FAILURE);
}
int main (int argc, char *argv[]) {

  /*printf(ANSI_COLOR_RED     "This text is RED!"     ANSI_COLOR_RESET "\n");
  printf(ANSI_COLOR_GREEN   "This text is GREEN!"   ANSI_COLOR_RESET "\n");
  printf(ANSI_COLOR_YELLOW  "This text is YELLOW!"  ANSI_COLOR_RESET "\n");
  printf(ANSI_COLOR_BLUE    "This text is BLUE!"    ANSI_COLOR_RESET "\n");
  printf(ANSI_COLOR_MAGENTA "This text is MAGENTA!" ANSI_COLOR_RESET "\n");
  printf(ANSI_COLOR_CYAN    "This text is CYAN!"    ANSI_COLOR_RESET "\n");*/
  
SDL_version test;
SDL_VERSION(&test);
SDL_Window *app=NULL;
SDL_Renderer *rend=NULL;
printf("Bienvenue sur la SDL version %d.%d.%d\n",test.major,test.minor,test.patch);
  printf("test\n");
  if(SDL_Init(SDL_INIT_VIDEO)!=0)
    SDL_ExitWithError("Initialision SDL");
  app=SDL_CreateWindow("Test de fenêtre...",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,WINDOW_WIDTH,WINDOW_HEIGHT,0);
  if (app==NULL)
    SDL_ExitWithError("Création de fenêtre échoué");
	//PrintHello();
 // Game();
    //Prog :
  rend=SDL_CreateRenderer(app,-1,SDL_RENDERER_SOFTWARE);
  if(rend==NULL)
    SDL_ExitWithError("Création rendu échouée");

  SDL_bool prg_launch=SDL_TRUE;

  
  if(SDL_SetRenderDrawColor(rend,63,0,255,SDL_ALPHA_OPAQUE)!=0)
    SDL_ExitWithError("Pas pu changer la couleur du rendu");
  if(SDL_RenderDrawPoint(rend,100,450)!=0){
    SDL_ExitWithError("Pas pu dessiné un point");
  }
  
  if(SDL_SetRenderDrawColor(rend,255,127,0,SDL_ALPHA_OPAQUE)!=0)
    SDL_ExitWithError("Pas pu changer la couleur du rendu");
  SDL_Rect rect;
  rect.x=300;
  rect.y=300;
  rect.w=200;
  rect.h=120;
  //Fill pour remplir et Draw pour dessiner contour
  if(SDL_RenderFillRect(rend,&rect)!=0){
    SDL_ExitWithError("Pas pu dessiné un rectangle");
  }
  if(SDL_SetRenderDrawColor(rend,63,0,255,SDL_ALPHA_OPAQUE)!=0)
    SDL_ExitWithError("Pas pu changer la couleur du rendu");
  if(SDL_RenderDrawLine(rend,50,50,500,500)!=0){
    SDL_ExitWithError("Pas pu dessiné une ligne");
  }
  SDL_RenderPresent(rend);
  while(prg_launch){
    SDL_Event event;
    while(SDL_PollEvent(&event)){
      switch(event.type){
        case SDL_QUIT:
          prg_launch=SDL_FALSE;
          break;
        default:
          break;

      }
    }
    
  }
  /*if(SDL_RenderClear(rend)!=0)
    SDL_ExitWithError("Effacement du rendu échoué");
*/

  //SDL_Delay(10000);
  SDL_DestroyRenderer(rend);
  SDL_DestroyWindow(app);
  SDL_Quit();

  return EXIT_SUCCESS;
}

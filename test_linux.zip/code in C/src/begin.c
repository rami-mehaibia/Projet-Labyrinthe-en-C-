#include<stdio.h>
#include<stdlib.h>
#include"structenum.h"

int GameMode() {

//asks the player if he or she wants to play player vs player or player vs computer
    int  choice;
    printf("what would you want between P v P or P v Com ?\n");
    fflush(stdout);
    scanf("%d",&choice);
    while(choice<1 || choice>2){
      printf("what would you want P v P or P v Com (the choices being 1 or 2) ?\n");
      fflush(stdout);
      scanf("%d",&choice);
    }
    if (choice == 1)
     {
        return 1;
      }     
    else{

        return 2;
    }

}
//*****
int askNumber(){


  int  number;
  printf("How many players are you ?\n");
  fflush(stdout);
  scanf("%d",&number);
  while(number<2 || number>4){
    printf("How many players are you (between 2 and 4) ?\n");
    fflush(stdout);
    scanf("%d",&number);
  }
  return number;
}
// ********
Player* createtable(int numPlayer){
	Player* players=(Player*)malloc(sizeof (Player)*numPlayer);
	return players;
}

Player* askName(Player* player,int numplayer){
	//
	for(int i=0;i<numplayer;i++){
		player[i].Name=(char*)malloc(50);
		printf("What is player %d's name ?\n",i+1);
    fflush(stdout);
		scanf("%s",player[i].Name);
		printf("What is player %d's age respecting this format : (Year Month)\n",i+1);
    fflush(stdout);
		scanf("%d %d",&player[i].age.Year,&player[i].age.Month);
	}

	

	return player;
	
}

//*********
void PrintfPlayerList(Player*player,int NumPlayer){
	printf("Here is the list of Players\n");
	for(int i=0 ; i < NumPlayer ; i++ ){
		printf("Player %d's Name : %s\nPlayer %d's age :%d years old and %d months\n",i+1,player[i].Name,i+1,player[i].age.Year,player[i].age.Month);
	}

}

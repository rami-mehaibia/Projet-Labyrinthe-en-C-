#ifndef BEGIN_H
#define BEGIN_H
#include "structenum.h"
int GameMode();
int askNumber();
Player* createtable(int numPlayer);
Player* askName(Player* player,int numplayer);
void PrintfPlayerList(Player*player,int NumPlayer);
#endif
#include<stdio.h>
#include<stdlib.h>
#include "begin.h"
#include "structenum.h"


void Game(){
  printf("Welcome to the Labyrinth Game\n");
  Gameboard gameboard;
  gameboard.choice=GameMode();
  if(gameboard.choice==1){
    gameboard.numplayer=askNumber();
		Player *players=createtable(gameboard.numplayer);
		players=askName(players, gameboard.numplayer);
	  PrintfPlayerList(players,gameboard.numplayer);
  }


}

#include <stdio.h>

char* PrintHello(){
	char* test="Hello from anoher universe !\n";
	printf("%s",test);
	
	return test;
}

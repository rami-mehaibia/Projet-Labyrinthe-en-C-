#ifndef STRUCTENUM_H
#define STRUCTENUM_H

typedef enum {Ishaped, Lshaped, Tshaped}Shape;
//----------------
typedef enum{Red, Blue, Green, Yellow}Colours;
//----------------
typedef enum {Same, Left, Right, Inverse} Orientation;
//----------------
typedef enum {Nothing, Dacia, Gallia, Britannia, Hispania, Egypt, Mesopotamia, Babylonia, Tripolitania, Armenia, Dalmetia, Macedonia, Thrace, Assyria, Numidia, Mauretania, Moesia, Galatia, Judaea, Pannonia, Aquitania, Raetia, Corsica, Sicilia, Sardinia, Cyprus}LOT;
//----------------
typedef enum {Movable, Unmovable} TileStatus;
//***************
typedef enum {false,true} Bool;
//***************

typedef struct {
  int Year;
  int Month;
} Age;

//***************
typedef struct {
int x , y;
} position;



typedef struct  {
  LOT* personalListTreasures;
  char* Name;
  Age age;
  Colours colour; //for character's colour, we're gonna put the basic ones...
  position positionPlayer;
  int treasurenumber; //aka we're at which treasure exactly rn ?
  int Maxtreasure; //the Max quantity of treasures this game...
  Bool AccessExit;
  Bool win;
  position positionExit;
} Player;
//*********

typedef struct {
  Shape shape;
  Orientation orientation;
   Bool tab[4]; // north south east west  
  LOT treasure;
  TileStatus tilestatus;
  Bool OutOfBounds;
  Bool IsPlayerPresent;
  int   HowManyPlayers;
  position  positionOfTile;
}Tile;

//******

typedef struct {


Tile gameboard[7][7];
  int choice ;//states the choice of the player 
  int turn ;//states the turn we're at...
  int numplayer;
} Gameboard;
//*********


#endif